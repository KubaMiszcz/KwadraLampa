Bluetooth Chat
==============

This is a port of the Android Level 8 SDK samples.

It demonstrates using the Bluetooth APIs to create a sample chat client.
